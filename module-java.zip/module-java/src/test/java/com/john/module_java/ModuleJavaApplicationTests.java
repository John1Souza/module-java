package com.john.module_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModuleJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
